export default function Dashboard() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
      <h1 className="text-2xl md:text-3xl font-semibold text-gray-900 text-center">Welcome to BragBoard Dashboard</h1>
    </div>
  )
}


